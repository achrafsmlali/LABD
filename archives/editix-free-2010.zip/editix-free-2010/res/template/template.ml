<?xml version="1.0" encoding="${default-encoding}"?>

<!-- New document created with EditiX at ${date} -->

<math xmlns="http://www.w3.org/1998/Math/MathML">
${cursor}
</math>